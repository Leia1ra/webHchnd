package com.web.hchnd.controller;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProfileImgUpload {
    // 파일 업로드 구현
    /*public List<DatafileVO> fileUpload(String path, List<MultipartFile> filesList){
        // 업로드한 파일 목록을 보관 DatafileVO -> list
        List<DatafileVO> uploadFileList = new ArrayList<DatafileVO>();

        if(filesList != null){ // 업로드 파일이 있을 때 if 1
            for(int i = 0; i<filesList.size(); i++){ // 첨부된 파일만큼 반복 수행 for 1
                MultipartFile mf = filesList.get(i);
                String orgFileName = mf.getOriginalFilename();// 파일 이름
                if(orgFileName != null && !orgFileName.equals("")){ // 원래 파일명이 있으면 if 2
                    // 이미 서버에 같은 파일명이 있으면 rename 수행해야 한다.
                    File f = new File(path, orgFileName);
                    if(f.exists()){ // 파일이 있으면 true if 3
                        // 파일명 찾기
                        for(int renameNum = 1; ; renameNum++){ // fileIndexing for 2
                            // 확장자와 파일명을 분리
                            int point = orgFileName.indexOf(".");
                            String fileNameNoExt = orgFileName.substring(0, point);// 파일명(확장자 제외)
                            String ext = orgFileName.substring(point+1); // 확장자

                            // 새로운 파일명 만들기
                            String newFilename= fileNameNoExt + "(" + renameNum +")." + ext;
                            f = new File(path, newFilename);
                            if(!f.exists()){ // 새로운 파일명이 서버에 있는지 확인 if 4
                                orgFileName = newFilename;
                                break;
                            } // if 4
                        } // for 2

                    } // if 3

                    // 업로드
                    try {
                        mf.transferTo(f);// 실제 서버에 업로드 된다
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    // 업로드할 파일 보관
                    DatafileVO fvo = new DatafileVO();
                    fvo.setFilename(orgFileName);
                    uploadFileList.add(fvo);
                } // if 2
            } // for 1
        } // if 1

        return uploadFileList;
    }*/
}
